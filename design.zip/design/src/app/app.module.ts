import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from '@app/material.module';
import { AppComponent } from '@app/app.component';
import { LabourCostReportComponent } from '@component/labour-cost-report/labour-cost-report.component';
import { LabourCostReportService } from '@service/labour-cost-report.service';

@NgModule({
  declarations: [AppComponent, LabourCostReportComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MaterialModule,
  ],
  providers: [LabourCostReportService],
  bootstrap: [AppComponent],
})
export class AppModule {}
