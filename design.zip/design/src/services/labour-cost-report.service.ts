import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '@env/environment';

@Injectable()
export class LabourCostReportService {
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  constructor(private http: HttpClient) {}

  getLabourStats() {
    const url = `${environment.apiUrl}${environment.routes.labourStats}`;
    return this.http.get<any>(url, this.httpOptions);
  }
}
